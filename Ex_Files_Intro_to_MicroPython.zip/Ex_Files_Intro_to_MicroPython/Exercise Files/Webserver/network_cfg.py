# Network credentials
CREDENTIALS = {"ssid":"SKYNET","pw":"11111111"}

# Network Timeout
NETWORK_TIMEOUT=30