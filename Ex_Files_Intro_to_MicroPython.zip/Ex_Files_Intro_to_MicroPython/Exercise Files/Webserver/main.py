######################################################
#
# Simple MicroPython Server
#
# Reports readings from a DHT20 temperature/humidity sensor
# Also, switches an LED on and off, and toggles its state
#
# Accepts incoming requests with paths of
#
# /switch/on       Switches on pin 18
# /switch/off      Switches off pin 18
# /switch/toggle   Toggles pin 18
# /sensor/update   Reports updated sensor info
#
######################################################

# Import standard modules
import machine, time, sys
import network, socket

# Import libraries for the display and DHT20 sensor
from ssd1306 import SSD1306_I2C
from dht20 import DHT20

# Import network configuration settings (ssid, pw, timeout)
from network_cfg import CREDENTIALS, NETWORK_TIMEOUT

# Main function implementing the web server
def main():

    # Set up switch pin
    switch = machine.Pin(18, machine.Pin.OUT)

    # Setup I2C, OLED display, and the temperature/humidity sensor
    i2c = machine.I2C(1, scl=machine.Pin(3), sda=machine.Pin(2))
    oled = SSD1306_I2C(128, 64, i2c, addr=0x3C)    
    sensor = DHT20(0x38, i2c)

    # Read the HTML dashboard template file
    f = open("html/dashboard.html", "r")
    html = f.read()
    f.close()

    # Connect to WiFi and create a socket
    wlan, ip, sock = connect_WiFi(oled, CREDENTIALS, NETWORK_TIMEOUT)
    print("Listening:", ip)

    # Update sensor values and status display
    temperature, humidity = DHT20_read(sensor)
    display_status(oled, ip, switch.value(), temperature, humidity)

    # Continually wait for and respond to HTML requests
    while True:

        # Accept a request and extract the path
        cl, addr = sock.accept()
        request = str(cl.recv(1024))
        path = path_from_request(request)
        cl.send('HTTP/1.0 200 OK\r\nContent-type: text/html\r\n\r\n')

        if resolve_path(path, switch, sensor):

            # Update and display the current status on the OLED display
            temperature, humidity = DHT20_read(sensor)
            temperature_text, \
            humidity_text, \
            switch_text, \
            IP_text = display_status(oled, ip, switch.value(), temperature, humidity)

            # Prepare and send the response
            cl.send(html.format(temp=temperature_text, humidity=humidity_text, switch=switch_text, ip=ip))

        else:
            print("Unrecognized Path:", path)

 
        # Close the connection and wait for things to settle
        cl.close()
        time.sleep_ms(20)

# Extract the path from an HTML request
def path_from_request(request_text):
    try:
        path = request_text.split(" ")[1]
    except IndexError:
        path = None
    return path

# Resolve the supplied HTML path
def resolve_path(path, switch, sensor):
    result = True
    if path == '/switch/on':
        switch.on()
    elif path == '/switch/off':
        switch.off()
    elif path == '/switch/toggle':
        switch.toggle()
    elif path == '/sensor/update' or path == "/":
        pass
    else:
        result = False
    return result
    
# Connect to a WiFi network
def connect_WiFi(d, credentials, timeout):

    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)

    display_message (d, credentials["ssid"],"Connecting")
    wlan.connect(credentials["ssid"],credentials["pw"])
    # Setup timer and wait for a timeout
    start = time.ticks_ms()
    try:
        while not wlan.isconnected():
            if time.ticks_diff(time.ticks_ms(), start) > (timeout*1000):
                raise RuntimeError('Timeout')
            time.sleep(1)
    except RuntimeError:
        display_message (d, credentials["ssid"],"Timeout")
        print("Timeout")
        sys.exit()
 
    # WiFi is connected. Get IP address and open socket
    ip = wlan.ifconfig()[0]
    s = socket.socket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((ip,80))
    s.listen(1)
    return (wlan, ip, s)

# Convert degrees centigrade to fahrenheit
def degrees_ctof(c):
    return ((c*9/5)+32)

# Get current temperature and humidity measurements
def DHT20_read(s):
    m = s.measurements
    t = degrees_ctof(m["t"])
    h = m["rh"]
    return (t, h) 
 
# Display a two line message on the OLED display
def display_message(d, txt1='', txt2=''):
    d.fill(0)
    d.text(txt1[:16], 0, 0)
    d.text(txt2[:16], 0, 14)
    d.show()

# Display server status (IP Address, Switch State, Temperature, Humidity)
def display_status(d, ip, switch, t, h):

    # Build status text using f-strings
    humidity_text    = f'{"Humidity":<8}' + f'{h:>7.2f}%'
    temperature_text = f'{"Temp":<8}'     + f'{t:>7.2f}F'
    switch_text      = f'{"Switch":<8}'   + f'{("On" if switch==1 else "Off"):>8}'
    IP_text          = f'IP{ip:>14}'

    # Define the x and y starting point of text (upper left corner), and the line height
    x, y, line_height = (0, 10, 13)

    # Clear the display and print out the lines
    d.fill(0)
    d.text(temperature_text, x, y)
    d.text(humidity_text, x, y+(1*line_height))
    d.text(switch_text, x, y+(2*line_height))
    d.text(IP_text, x, y+(3*line_height))
    d.show()
    
    # Return HTML text to insert in the dashboard page
    return (temperature_text, humidity_text, switch_text, IP_text)

# Only run main() if this is the main module, not imported by andother module
if __name__ == '__main__':
    main()
